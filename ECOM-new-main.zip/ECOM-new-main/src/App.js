import AppRoutes from './components/routes/AppRoutes';

const App = () => {

  return (
    <AppRoutes />
  )

}

export default App